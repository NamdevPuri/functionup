

// const mid4= function ( req, res, next) {
//     console.log("Hi I am a middleware named Mid4")
//     //counter
//     next()
// }

// const isFreeAppUser= function(req, res, next){
//     let appuser= req.headers.isFreeAppUser
//     if (req.headers.isFreeAppUser == true){
//         next()
//     }else{
//         res.send({msg:"header is mandatory"})
//     }
//     }


// module.exports.mid4= mid4
// module.exports.isFreeAppUser= isFreeAppUser
