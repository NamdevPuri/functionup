const authorModel = require("../models/authorModel")
const bookModel= require("../models/bookModel")

const createBook= async function (req, res) {
    let book = req.body
    let bookCreated = await bookModel.create(book)
    res.send({data: bookCreated})
}

// const getBooksData= async function (req, res) {
//     let books = await bookModel.find()
//     res.send({data: books})
// }

const getBooksWithAuthorDetails = async function (req, res) {
    let specificBook = await bookModel.find().populate('author').populate('all_books').populate.apply('publisher')
    res.send({data: specificBook})

}


//question 5a

const bookUpdateIsHardCover = async function (req, res){
    let saveData = await bookModel.find().updateMany({publisher:{$in:[ , ]  },
    },
    {$set:{isHardCover:true}}, {upsert:false});
    res.send({msg:saveData});
}

// question 5b
const updateData = async function (req, res){
    let saveData= await authorModel.find({rating:{$gte: 3.5}}).select({_id:1})
    await bookModel.updateMany({author:{$in:data}},{$in:{price:100}})
    res.send({msg:saveData})
}




module.exports.createBook= createBook
// module.exports.getBooksData= getBooksData
module.exports.getBooksWithAuthorDetails = getBooksWithAuthorDetails
module.exports.bookUpdateIsHardCover = bookUpdateIsHardCover
module.exports.updateData = updateData