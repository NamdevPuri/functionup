const mongoose = require('mongoose');



const bookSchema = new mongoose.Schema( {
    name: String,
    author_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Author"
    },
    publisher:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Publisher",
    },
    price: Number,
    ratings: Number,
    isHardCover: { default: false }

}, { timestamps: true });


module.exports = mongoose.model('Book', bookSchema)
